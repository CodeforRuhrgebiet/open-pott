var map;

<!-- Map Controls -->
var info = L.control();
var legend;

<!-- Plugins -->
var scale;

<!-- Layers for the map -->
var gemein = new L.LayerGroup();

<!-- Overlay Layers -->
var overlays = { "Open Data Verf&uumlgbarkeit": gemein};
var overlays2 = {  }

<!-- geoJson data-->
var geojson;

function init(){

    <!-- Set the map parameters -->
    //7.208449443900787, 51.537503853624365
    
    map = L.map('map').setView([51.5, 7.2], 10);
    map.options.maxZoom = 18;
    map.options.minZoom = 5;

    <!-- copyright informations -->
    mapLink = '<a href="http://openstreetmap.org">OpenStreetMap</a>';
    usedDataLink = '<a href="https://open.nrw/">Open.NRW</a>';

    <!-- Add copyright information to the map -->
    L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
	{
        attribution: '&copy; ' + 'Tiles courtesy of ' + mapLink +
		' under <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a></br>'
		+ 'Data source: ' + usedDataLink, maxZoom: 18,
	}).addTo(map);
	
	<!-- Map Legends and info control Init -->
    loadLegends();
    legend.addTo(map);
    infoControlInit();
	
    <!-- Plugin Init -->
    scaleInit();
    
    <!-- load Geojon Layers -->
    loadData();
}

