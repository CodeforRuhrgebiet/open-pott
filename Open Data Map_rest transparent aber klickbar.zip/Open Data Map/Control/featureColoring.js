function highlightFeature(e)
{
                	var layer = e.target;

                	layer.setStyle({
                    		weight: 5,
                    		color: 'black',
                    		dashArray: ''

                	});

                	if (!L.Browser.ie && !L.Browser.opera) {
                    		layer.bringToFront();
                	}

                	info.update(layer.feature.properties);
}

function resetHighlight(e)
{
                	geojson.resetStyle(e.target);
                	info.update();
}




function onEachFeature6(feature, layer){

                      //feature.properties.GN + '</br>' + feature.properties.DSL + '% DSL Verf�gbarkeit >= 50 MBit');



                    layer.on(
                       {
                    		mouseover: highlightFeature,
                    		mouseout: resetHighlight,
                	    }
                    );
                    
                   layer.bindPopup('<b>' + feature.properties.GN + '</b></br>'
                                + 'Open Data Portal: ' + feature.properties["Open Data Portal"] + '</br>'
                                + 'Website: <a href="' + feature.properties.Website + '">' + feature.properties.Website + '</a></br>'
                                + 'CKAN / DCAN: ' + feature.properties["CKAN\/DCAN"] + '</br>'
                                + 'Maschinenlesbare Formate: ' + feature.properties["Maschinenlesbare Formate"] + '</br>'
                                + 'Lizenz: ' + feature.properties["Lizenz"] + '</br>'
                                + 'OGD-Metadaten Pflichtfelder: ' + feature.properties["OGD-Metadaten Pflichtfelder"] + '</br>'
                                + 'Anbindung an Open.NRW Portal: ' + feature.properties["Anbindung Open.NRW Portal"]
                 );
                    
                 info.update(layer.feature.properties);
}

function style6(feature)
{
        if(
            feature.properties["GN"] == "Breckerfeld" | feature.properties["GN"] == "Ennepetal" | feature.properties["GN"] == "Gevelsberg" |
            feature.properties["GN"] == "Hattingen" | feature.properties["GN"] == "Herdecke" | feature.properties["GN"] == "Schwelm" |
            feature.properties["GN"] == "Sprockhövel" | feature.properties["GN"] == "Wetter (Ruhr)" | feature.properties["GN"] == "Witten" |
            feature.properties["GN"] == "Werne" | feature.properties["GN"] == "Unna" | feature.properties["GN"] == "Selm" |
            feature.properties["GN"] == "Schwerte" | feature.properties["GN"] == "Lünen" | feature.properties["GN"] == "Kamen" |
            feature.properties["GN"] == "Holzwickede" | feature.properties["GN"] == "Fröndenberg" | feature.properties["GN"] == "Bönen" |
            feature.properties["GN"] == "Bergkamen" | feature.properties["GN"] == "Waltrop" | feature.properties["GN"] == "Recklinghausen" |
            feature.properties["GN"] == "Oer-Erkenschwick" | feature.properties["GN"] == "Marl" | feature.properties["GN"] == "Herten" |
            feature.properties["GN"] == "Haltern" | feature.properties["GN"] == "Gladbeck" | feature.properties["GN"] == "Dorsten" |
            feature.properties["GN"] == "Datteln" | feature.properties["GN"] == "Castrop-Rauxel" | feature.properties["GN"] == "Hattingen" |
            feature.properties["GN"] == "Alpen" | feature.properties["GN"] == "Dinslaken" | feature.properties["GN"] == "Hamminkeln" |
            feature.properties["GN"] == "Xanten" | feature.properties["GN"] == "Wesel" | feature.properties["GN"] == "Voerde (Niederrhein)" |
            feature.properties["GN"] == "Sonsbeck" | feature.properties["GN"] == "Schermbeck" | feature.properties["GN"] == "Rheinberg" |
            feature.properties["GN"] == "Neukirchen-Vluyn" | feature.properties["GN"] == "Moers" | feature.properties["GN"] == "Kamp-Lintfort" |
            feature.properties["GN"] == "Hünxe" | feature.properties["GN"] == "Oberhausen" | feature.properties["GN"] == "Mülheim an der Ruhr" |
            feature.properties["GN"] == "Herne" | feature.properties["GN"] == "Hamm" | feature.properties["GN"] == "Hagen" |
            feature.properties["GN"] == "Gladbeck" | feature.properties["GN"] == "Bochum" | feature.properties["GN"] == "Bottrop" |
            feature.properties["GN"] == "Dortmund" | feature.properties["GN"] == "Duisburg" | feature.properties["GN"] == "Essen" |
            feature.properties["GN"] == "Gelsenkirchen" | feature.properties["GN"] == "Haltern am See"
        ){
            if(feature.properties["Open Data Portal"] == "Ja"){

                return {
                   			weight: 2,
                   			opacity: 1,
                   			color: 'white',
                  			dashArray: '3',
                   			fillOpacity: 0.7,
                   			fillColor: "green"
                };

            }
            else if(feature.properties["Open Data Portal"] == "In Planung"){
                return {
                   			weight: 2,
                   			opacity: 1,
                   			color: 'white',
                  			dashArray: '3',
                   			fillOpacity: 0.7,
                   			fillColor: "yellow"
                };
            }
            else{

                return {
                   			weight: 2,
                   			opacity: 1,
                   			color: 'white',
                  			dashArray: '3',
                   			fillOpacity: 0.7,
                   			fillColor: "red"
                };
            }
        }
        else{
            //if(feature.properties["Open Data Portal"] == "Ja"){

//                return {
//                   			weight: 2,
//                   			opacity: 1,
//                   			color: 'white',
//                  			dashArray: '3',
//                   			fillOpacity: 0.0,
//                   			fillColor: "white"
//                };

            //}
//            else if(feature.properties["Open Data Portal"] == "In Planung"){
//                return {
//                   			weight: 2,
//                   			opacity: 1,
//                   			color: 'white',
//                  			dashArray: '3',
//                   			fillOpacity: 0.3,
//                   			fillColor: "yellow"
//                };
//            }
//            else{
//
                return {
                   			weight: 0,
                   			opacity: 0,
                  			color: 'transparent',
                  			dashArray: '3',
                   			fillOpacity: 0.0,
                   			fillColor: "transparent"
                };
//            }
        }
}