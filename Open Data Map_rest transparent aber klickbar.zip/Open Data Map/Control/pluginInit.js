function scaleInit()
{
	L.control.scale(
        {
            metric: true,
            imperial: false,
            position: 'bottomleft'
        }
    ).addTo(map);
}