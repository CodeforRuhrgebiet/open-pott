//This function defines, what has to happen with the legends when they are loadded
function loadLegends()
{
	   //add the legend for the data to the map
       legend = L.control(
            {
                position: 'bottomright'
            }
       );

	    //logic behind the unemployed legend
        legend.onAdd = function (map) {
                var div = L.DomUtil.create('div', 'info legend'),
                    labels = ['<strong>Open Data</strong>'];

                        div.innerHTML += labels.push(
                        '<i style="background:' + '#FF0000' + '"></i> ' + "Nein");

                        div.innerHTML += labels.push(
                        '<i style="background:' + '#FFFF00' + '"></i> ' + "In Planung");

                        div.innerHTML += labels.push(
                        '<i style="background:' + '#008000' + '"></i> ' + "Ja");


                    div.innerHTML = labels.join('<br>');
                    return div;

         };
}