function loadData()
{
    <!-- Load GeoJson and set it to Layers -->
    geojson = L.geoJson( open,
        {
            style: style6,
            onEachFeature: onEachFeature6
        }
    ).addTo(gemein);

    <!-- Init the standard selected layer -->
    map.addLayer(gemein);
    
//    <!-- add the layers to the map if more than one... -->
//    L.control.layers( overlays, overlays2, {
//                                        collapsed: false,
//                                        position: 'bottomleft'
//                                     }
//    ).addTo(map);
}