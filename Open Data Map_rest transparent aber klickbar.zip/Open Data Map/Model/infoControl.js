function infoControlInit()
{
    <!-- add the infocontrol to the map -->
    info.onAdd = function (map)
    {
            this._div = L.DomUtil.create('div', 'info');
            this.update();
            return this._div;
    };

	<!-- logic behind the infocontrol -->
    info.update = function (props)
    {
            this._div.innerHTML =
                '<h4>Open Data Verf&uumlgbarkeit 2016</h4>'
                + (
                    props ? '<b>' + props.GN + '</b><br />'
                    : '<i>Weitere Daten werden durch </br>Klick angezeigt</i>'
                  );
    };
    
    info.addTo(map);
}